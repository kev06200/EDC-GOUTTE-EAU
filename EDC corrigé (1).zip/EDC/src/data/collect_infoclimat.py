"""
collect_infoclimat.py
---------------------
Lit un fichier CSV exporté depuis le site Infoclimat et range les données
dans la base SQLite créée par database.py.
 
Ce que fait ce script :
1. Lit le CSV (en ignorant les lignes de commentaires "#" et la ligne des unités).
2. Récupère le nom de chaque station dans les commentaires du début du fichier.
3. Le fichier contient des mesures toutes les 10, 15 ou 30 minutes : on les
   regroupe pour obtenir UNE ligne par station et par jour
   (pluie du jour, température min / max / moyenne, vent moyen).
4. Insère le résultat dans la base (tables "station" puis "observation").
 
Utilisation (depuis le dossier EDC, dans l'invite de commande) :
    python -m src.data.collect_infoclimat
ou avec un autre fichier :
    python -m src.data.collect_infoclimat data/raw/mon_autre_export.csv
"""
 
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
 
import pandas as pd
 
from src.data.database import get_connection, upsert_observations, upsert_station
 
# Racine du projet (le dossier EDC) : database.py est dans EDC/src/data/
RACINE = Path(__file__).resolve().parents[2]
CSV_PAR_DEFAUT = RACINE / "data" / "raw" / "export_infoclimat.csv"
 
# Une journée n'est gardée que si on a au moins ce nombre de mesures horaires
# de pluie (sur 24 possibles). Cela écarte les journées incomplètes,
# par exemple la journée en cours au moment de l'export.
MIN_HEURES_PLUIE = 22
 
 
def lire_noms_stations(chemin: Path) -> dict:
    """Lit les lignes '# 00049: Saint-Symphorien - Verrières' au début du fichier
    et renvoie un dictionnaire {station_id: nom}."""
    noms = {}
    with open(chemin, encoding="utf-8") as f:
        for ligne in f:
            if not ligne.startswith("#"):
                break  # les commentaires sont tous au début : on s'arrête à l'en-tête
            m = re.match(r"#\s+(\S+):\s+(.+)", ligne.strip())
            if m:
                noms[m.group(1)] = m.group(2)
    return noms
 
 
def lire_et_agreger(chemin: Path) -> pd.DataFrame:
    """Transforme les mesures fines de l'export en une ligne par station et par jour."""
    df = pd.read_csv(chemin, sep=";", comment="#", dtype=str, encoding="utf-8")
 
    # La 1re ligne après l'en-tête contient les unités ("°C", "hPa"...) :
    # sa "date" n'est pas une vraie date, elle disparaît donc ici.
    df["dh_utc"] = pd.to_datetime(df["dh_utc"], format="%Y-%m-%d %H:%M:%S", errors="coerce")
    df = df.dropna(subset=["dh_utc"])
 
    for col in ["temperature", "pluie_1h", "vent_moyen"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
 
    df["obs_date"] = df["dh_utc"].dt.strftime("%Y-%m-%d")
 
    jour = (
        df.groupby(["station_id", "obs_date"])
        .agg(
            rr=("pluie_1h", "sum"),          # pluie du jour = somme des cumuls horaires
            n_pluie=("pluie_1h", "count"),   # combien de mesures horaires on a
            tn=("temperature", "min"),
            tx=("temperature", "max"),
            tm=("temperature", "mean"),
            ffm=("vent_moyen", "mean"),      # en km/h dans l'export
        )
        .reset_index()
    )
 
    avant = len(jour)
    jour = jour[jour["n_pluie"] >= MIN_HEURES_PLUIE].copy()
    ecartees = avant - len(jour)
    if ecartees:
        print(f"{ecartees} journée(s) incomplète(s) ignorée(s) (moins de {MIN_HEURES_PLUIE} mesures horaires de pluie).")
 
    # La base attend le vent en m/s, l'export est en km/h
    jour["ffm"] = jour["ffm"] / 3.6
    return jour.round({"rr": 1, "tn": 1, "tx": 1, "tm": 1, "ffm": 2})
 
 
def _vers_python(x):
    """Remplace les valeurs manquantes (NaN) par None, que SQLite sait ranger."""
    return None if pd.isna(x) else float(x)
 
 
def importer(chemin: Path):
    if not chemin.exists():
        print(f"Fichier introuvable : {chemin}")
        print("Copie ton export dans le dossier EDC\\data\\raw\\ (à créer si besoin).")
        return
 
    noms = lire_noms_stations(chemin)
    jour = lire_et_agreger(chemin)
    if jour.empty:
        print("Aucune journée complète dans ce fichier : rien à insérer.")
        return
 
    conn = get_connection()
 
    # 1) D'abord les stations (la base l'exige avant les observations).
    #    L'export ne donne pas latitude / longitude / altitude : on laisse vide.
    for station_id in jour["station_id"].unique():
        nom = noms.get(station_id, station_id)
        upsert_station(conn, station_id, nom, None, None, None)
 
    # 2) Ensuite les observations journalières
    maintenant = datetime.now(timezone.utc).isoformat()
    rows = [
        (
            r.station_id, r.obs_date,
            _vers_python(r.rr), _vers_python(r.tn), _vers_python(r.tx),
            _vers_python(r.tm), _vers_python(r.ffm),
            chemin.name, maintenant,
        )
        for r in jour.itertuples(index=False)
    ]
    upsert_observations(conn, rows)
    conn.commit()
    conn.close()
 
    print(f"{len(rows)} lignes (station x jour) enregistrées "
          f"pour {jour['station_id'].nunique()} stations, "
          f"du {jour['obs_date'].min()} au {jour['obs_date'].max()}.")
 
 
if __name__ == "__main__":
    chemin = Path(sys.argv[1]) if len(sys.argv) > 1 else CSV_PAR_DEFAUT
    importer(chemin)