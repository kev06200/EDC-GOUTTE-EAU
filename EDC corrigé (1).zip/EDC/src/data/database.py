"""
database.py
-----------
Ce module va créer un fichier .db où seront rangées les valeurs collectées sur le site meteo gouv. Le fichier créée sera dans .\data\processed\goutte_eau.db
"""

import sqlite3
from pathlib import Path

# Chemin du fichier de base de données. On le place dans data/processed/
DB_PATH = Path(__file__).resolve().parents[2] / "data" / "processed" / "goutte_eau.db"

# Le schéma SQL complet, sous forme de texte.
# On y définit 4 tables :
#   - station      : les stations météo (une ligne par station)
#   - observation  : les mesures quotidiennes (pluie, température...)
#   - model_run    : l'historique des entraînements de modèles
#   - prediction   : les prédictions faites par l'API (pour audit/traçabilité)
SCHEMA = """
PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;

CREATE TABLE IF NOT EXISTS station (
    station_id TEXT PRIMARY KEY,
    name       TEXT NOT NULL,
    latitude   REAL,
    longitude  REAL,
    altitude   REAL,
    region     TEXT NOT NULL DEFAULT 'Occitanie'
);

CREATE TABLE IF NOT EXISTS observation (
    station_id  TEXT NOT NULL REFERENCES station(station_id),
    obs_date    TEXT NOT NULL,          -- format ISO : 'YYYY-MM-DD'
    rr          REAL,                   -- pluie en mm sur 24h
    tn          REAL,                   -- température minimale (°C)
    tx          REAL,                   -- température maximale (°C)
    tm          REAL,                   -- température moyenne (°C)
    ffm         REAL,                   -- vent moyen (m/s)
    source_url  TEXT,
    ingested_at TEXT NOT NULL,
    PRIMARY KEY (station_id, obs_date)
);

CREATE TABLE IF NOT EXISTS model_run (
    model_version  TEXT PRIMARY KEY,
    trained_at     TEXT NOT NULL,
    train_start    TEXT,
    train_end      TEXT,
    features_json  TEXT,
    metrics_json   TEXT,
    artifact_path  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS prediction (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    station_id    TEXT,
    target_date   TEXT,
    probability   REAL,
    risk_level    TEXT,
    model_version TEXT,
    created_at    TEXT
);

CREATE INDEX IF NOT EXISTS ix_obs_date ON observation(obs_date);
CREATE INDEX IF NOT EXISTS ix_prediction_station_date
    ON prediction(station_id, target_date);
"""


def get_connection() -> sqlite3.Connection:
    """Ouvre (ou crée) le fichier de base de données et s'assure que les
    tables existent. C'est la fonction à appeler partout ailleurs dans le
    projet pour parler à la base."""
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.executescript(SCHEMA)
    return conn


def upsert_station(conn, station_id, name, lat, lon, alt, region="Occitanie"):
    """Insère une station, ou ne fait rien si elle existe déjà (INSERT OR IGNORE)."""
    conn.execute(
        """INSERT OR IGNORE INTO station (station_id, name, latitude, longitude, altitude, region)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (station_id, name, lat, lon, alt, region),
    )


def upsert_observations(conn, rows):
    """Insère une liste d'observations. Si une observation (station, date)
    existe déjà, on la remplace (UPSERT) pour permettre de relancer la
    collecte sans créer de doublons.

    `rows` est une liste de tuples :
    (station_id, obs_date, rr, tn, tx, tm, ffm, source_url, ingested_at)
    """
    conn.executemany(
        """
        INSERT INTO observation (station_id, obs_date, rr, tn, tx, tm, ffm, source_url, ingested_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(station_id, obs_date) DO UPDATE SET
            rr=excluded.rr, tn=excluded.tn, tx=excluded.tx, tm=excluded.tm,
            ffm=excluded.ffm, source_url=excluded.source_url, ingested_at=excluded.ingested_at
        """,
        rows,
    )


def save_model_run(conn, model_version, trained_at, train_start, train_end,
                    features_json, metrics_json, artifact_path):
    """Journalise un entraînement de modèle (pour C14 : traçabilité)."""
    conn.execute(
        """INSERT OR REPLACE INTO model_run
           (model_version, trained_at, train_start, train_end, features_json, metrics_json, artifact_path)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (model_version, trained_at, train_start, train_end, features_json, metrics_json, artifact_path),
    )


def save_prediction(conn, station_id, target_date, probability, risk_level, model_version, created_at):
    """Enregistre chaque prédiction faite par l'API (traçabilité / audit)."""
    conn.execute(
        """INSERT INTO prediction (station_id, target_date, probability, risk_level, model_version, created_at)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (station_id, target_date, probability, risk_level, model_version, created_at),
    )


if __name__ == "__main__":
    conn = get_connection()
    print(f"Base de données prête : {DB_PATH}")
    conn.close()